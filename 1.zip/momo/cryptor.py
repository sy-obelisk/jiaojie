# coding=utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

import json
import base64

BIND = '''{"+" : "H", "/" : "I", "1" : "9", "0" : "U", "3" : "A", "2" : "V", "5" : "f", "4" : "E", "7" : "b", "6" : "a", "9" : "0", "8" : "O", "=" : "z", "A" : "x", "C" : "Q", "B" : "G", "E" : "M", "D" : "1", "G" : "R", "F" : "W", "I" : "F", "H" : "3", "K" : "t", "J" : "l", "M" : "s", "L" : "c", "O" : "X", "N" : "K", "Q" : "e", "P" : "o", "S" : "u", "R" : "/", "U" : "y", "T" : "T", "W" : "p", "V" : "Y", "Y" : "P", "X" : "D", "Z" : "Z", "a" : "L", "c" : "i", "b" : "2", "e" : "d", "d" : "4", "g" : "n", "f" : "h", "i" : "N", "h" : "k", "k" : "5", "j" : "8", "m" : "r", "l" : "q", "o" : "J", "n" : "g", "q" : "m", "p" : "v", "s" : "7", "r" : "6", "u" : "w", "t" : "+", "w" : "j", "v" : "=", "y" : "B", "x" : "C", "z" : "S"}'''

def ascll(string, encode):
	dictionary = json.loads(BIND)
	if encode == True:
		dictionary = dict(zip(dictionary.values(), dictionary.keys()))
	decode = ''
	for char in string:
		value = dictionary[char]
		decode += value
	return decode

def deascll(string):
	return ascll(string, False)

def enascll(string):
	return ascll(string, True)


def half(string, maxfloor, curfloor):
	length = len(string)
	if length <= 2:
		return string
	count = length / 2
	left = string[:count]
	center = ''
	curfloor += 1
	if count * 2 != length:
		center = string[count]
		count += 1
	right = string[count:]
	if curfloor < maxfloor:
		left = half(left, maxfloor, curfloor)
		right = half(right, maxfloor, curfloor)
	return right + center + left

def sort(string):
	string = string.decode('utf-8')
	maxfloorarray = [0, 8, 21, 55, 149, 404, 800, 10000]
	length = len(string)
	maxfloor = 0
	for i in range(len(maxfloorarray)):
		floorlength = maxfloorarray[i]
		if length < floorlength:
			maxfloor = i
			if maxfloor == 1:
				maxfloor = 0
			elif maxfloor == len(maxfloorarray) - 1:
				print 'ERROR: 出错, 暂未找到大于此字符串位数的临界层数, 请手动找到层数临界值'
			break
	decode = half(string, maxfloor, 0)
	return decode

def decode(string):
	string = deascll(string)
	string = base64.b64decode(string)
	string = sort(string)
	return string

def encode(string):
	string = sort(string)
	string = base64.b64encode(string)
	string = enascll(string)
	return string

























def insertnotesql():
	import sqlite3
	sqlite = sqlite3.connect('maimemo.v3_2_3.db')
	cursor = sqlite.cursor()
	sql = 'select * from NT_TB'
	cursor.execute(sql)
	result = cursor.fetchall()
	for model in result:
		noteid = model[0]
		noteencode = model[2]
		notedecode = decode(noteencode)
		notedecode = notedecode.replace("\'", "''")
		sql = 'update NT_TB set pl_note = ' + '\'' + notedecode + '\'' + ' where nt_note_id = ' +  '\'' + noteid + '\''
		cursor.execute(sql)
	sqlite.commit()

def insertvocsql():
	import sqlite3
	sqlite = sqlite3.connect('maimemo.v3_2_3.db')
	cursor = sqlite.cursor()
	sql = 'select * from VOC_TB'
	cursor.execute(sql)
	result = cursor.fetchall()
	for model in result:
		vocid = model[0]
		interencode = model[5]
		interdecode = decode(interencode)
		interdecode = interdecode.replace("\'", "''")
		sql = 'update VOC_TB set pl_interpretation = ' + '\'' + interdecode + '\'' + ' where vc_id = ' +  '\'' + vocid + '\''
		cursor.execute(sql)
	sqlite.commit()


def testencode(string):
	string = encode(string)
	print string


def testdecode(string):
	string = decode(string)
	print string


if __name__ == '__main__':
	string = '/8FuMQ6VmtNYM8Qen8Q6f86OKSqOK8QLcUXhpVsggVXJWaG7r/B0kP8=OCvv'
	testdecode(string)

	string = '[联想] 低着头看着的时间 就是⏰'
	testencode(string)

	insertvocsql()







